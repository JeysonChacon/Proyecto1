from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

class SistemaHCE:
    def __init__(self):
        self.usuarios = {
            "pacientes": [],
            "doctores": [],
            "administradores": []
        }

    def registrar_usuario(self, tipo, nombre):
        if tipo in self.usuarios:
            self.usuarios[tipo].append(nombre)
        else:
            print("Tipo de usuario no válido")

    def cantidad_usuarios(self, tipo):
        if tipo in self.usuarios:
            return len(self.usuarios[tipo])
        else:
            print("Tipo de usuario no válido")
            return 0

    def cantidad_total_usuarios(self):
        total = 0
        for tipo in self.usuarios:
            total += len(self.usuarios[tipo])
        return total

    def mostrar_usuarios(self):
        usuarios_dict = {}
        for tipo, lista_usuarios in self.usuarios.items():
            usuarios_dict[tipo] = lista_usuarios
        return usuarios_dict

sistema_hce = SistemaHCE()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/registrar', methods=['POST'])
def registrar():
    tipo = request.form['tipo']
    nombre = request.form['nombre']
    sistema_hce.registrar_usuario(tipo, nombre)
    return redirect(url_for('index'))

@app.route('/cantidad', methods=['POST'])
def cantidad():
    tipo = request.form['tipo']
    cantidad = sistema_hce.cantidad_usuarios(tipo)
    return render_template('cantidad.html', tipo=tipo, cantidad=cantidad)

@app.route('/total')
def total():
    total_usuarios = sistema_hce.cantidad_total_usuarios()
    usuarios = sistema_hce.mostrar_usuarios()
    return render_template('total.html', total=total_usuarios, usuarios=usuarios)

if __name__ == '__main__':
    app.run(debug=True)
